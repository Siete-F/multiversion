
# ============== MAIN FUNCTIONALITY ==============

# -------------- do something --------------

#' Who are these coming to the sacrifice?
#' To what green altar, O mysterious priest,
#' Lead’st thou that heifer lowing at the skies,
#' And all her silken flanks with garlands drest?
#' What little town by river or sea shore,
#' Or mountain-built with peaceful citadel,
#' Is emptied of this folk, this pious morn?
#' And, little town, thy streets for evermore
#' Will silent be; and not a soul to tell
#' Why thou art desolate, can e’er return.
#' 
#' O Attic shape! Fair attitude! with brede
#' Of marble men and maidens overwrought,
#' With forest branches and the trodden weed;
#' Thou, silent form, dost tease us out of thought
#' As doth eternity: Cold Pastoral!
#' When old age shall this generation waste,
#' Thou shalt remain, in midst of other woe
#' Than ours, a friend to man, to whom thou say’st,
#' “Beauty is truth, truth beauty,—that is all
#' Ye know on earth, and all ye need to know.”#'
#'
#' @param a The best input ever
#' @param b The awesome second input
#' @export
#'
package_c1 <- function(a, b) {
	return('package_c1')
}

#' Just some example function.
#' But this function will also be present in another package.
#'
#' @export
#'
what_version_are_you <- function() {
    return('15.2.8')
}

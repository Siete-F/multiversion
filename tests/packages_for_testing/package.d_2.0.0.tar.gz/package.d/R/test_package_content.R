
# ============== MAIN FUNCTIONALITY ==============

# -------------- do something --------------

#' Tell me not, in mournful numbers,
#' Life is but an empty dream!
#' For the soul is dead that slumbers,
#' And things are not what they seem.
#' 
#' Life is real! Life is earnest!
#' And the grave is not its goal;
#' Dust thou art, to dust returnest,
#' Was not spoken of the soul.
#' 
#' Not enjoyment, and not sorrow,
#' Is our destined end or way;
#' But to act, that each tomorrow
#' Find us farther than today.
#' 
#' Art is long, and Time is fleeting,
#' And our hearts, though stout and brave,
#' Still, like muffled drums, are beating
#' Funeral marches to the grave.
#' 
#' In the world’s broad field of battle,
#' In the bivouac of Life,
#' Be not like dumb, driven cattle!
#' Be a hero in the strife!A_Psalm_of_Life
#' 
#' Trust no Future, howe’er pleasant!
#' Let the dead Past bury its dead!
#' Act,—act in the living Present!
#' Heart within, and God o’erhead!
#' 
#' Lives of great men all remind us
#' We can make our lives sublime,
#' And, departing, leave behind us
#' Footprints on the sands of time;—
#' 
#' Footprints, that perhaps another,
#' Sailing o’er life’s solemn main,
#' A forlorn and shipwrecked brother,
#' Seeing, shall take heart again.
#' 
#' Let us, then, be up and doing,
#' With a heart for any fate;
#' Still achieving, still pursuing,
#' Learn to labor and to wait.
#'
#' @param a The best input ever
#' @param b The awesome second input
#' @export
#'
package_d2 <- function(a, b) {
	return('package_d2')
}

#' Just some example function.
#' But this function will also be present in another package.
#'
#' @export
#'
what_version_are_you <- function() {
    return('2.0.0')
}

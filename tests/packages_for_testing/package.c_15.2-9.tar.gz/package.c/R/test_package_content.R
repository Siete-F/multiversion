
# ============== MAIN FUNCTIONALITY ==============

# -------------- do something --------------

#' Tiger Tiger, burning bright,
#' In the forests of the night;
#' What immortal hand or eye,
#' Could frame thy fearful symmetry?
#' 
#' In what distant deeps or skies.
#' Burnt the fire of thine eyes?
#' On what wings dare he aspire?
#' What the hand, dare seize the fire?
#' 
#' And what shoulder, and what art,
#' Could twist the sinews of thy heart?
#' And when thy heart began to beat,
#' What dread hand? and what dread feet?
#' 
#' What the hammer? what the chain,
#' In what furnace was thy brain?
#' What the anvil? what dread grasp,
#' Dare its deadly terrors clasp!
#' 
#' When the stars threw down their spears
#' And water’d heaven with their tears:
#' Did he smile his work to see?
#' Did he who made the Lamb make thee?
#' 
#' Tiger Tiger burning bright,
#' In the forests of the night:
#' What immortal hand or eye,
#' Dare frame thy fearful symmetry?
#'
#' @param a The best input ever
#' @param b The awesome second input
#' @export
#'
package_c2 <- function(a, b) {
	return('package_c2')
}

#' Just some example function.
#' But this function will also be present in another package.
#'
#' @export
#'
what_version_are_you <- function() {
    return('15.2.9')
}

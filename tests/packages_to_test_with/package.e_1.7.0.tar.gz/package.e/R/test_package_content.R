
# ============== MAIN FUNCTIONALITY ==============

# -------------- do something --------------

#' Death, be not proud, though some have called thee
#' Mighty and dreadful, for thou art not so;
#' For those whom thou think’st thou dost overthrow
#' Die not, poor Death, nor yet canst thou kill me.
#' From rest and sleep, which but thy pictures be,
#' Much pleasure; then from thee much more must flow,
#' And soonest our best men with thee do go,
#' Rest of their bones, and soul’s delivery.
#' Thou art slave to fate, chance, kings, and desperate men,
#' And dost with poison, war, and sickness dwell,
#' And poppy or charms can make us sleep as well
#' And better than thy stroke; why swell’st thou then?
#' One short sleep past, we wake eternally
#' And death shall be no more; Death, thou shalt die.
#'
#' @param a The best input ever
#' @param b The awesome second input
#' @export
#'
package_e2 <- function(a, b) {
	return('package_e2')
}

#' Just some example function.
#' But this function will also be present in another package.
#'
#' @export
#'
what_version_are_you <- function() {
    return('1.7.0')
}
